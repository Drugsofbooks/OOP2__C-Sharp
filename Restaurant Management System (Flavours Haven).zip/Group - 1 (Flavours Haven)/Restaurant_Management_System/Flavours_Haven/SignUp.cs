﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Flavours_Haven
{
    public partial class signUP : Form
    {
        private formLogin FormLogin;
        private Data_Access Da;
        public signUP()
        {
            Da = new Data_Access();
            InitializeComponent();
        }
        public signUP(formLogin FormLogin)
        {
            this.Da = new Data_Access();
            this.FormLogin = FormLogin;
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            bool status = checkBox1.Checked;
            switch (status)
            {
                case true:
                    txtSetPassword.UseSystemPasswordChar = false;
                    txtConfirmPassword.UseSystemPasswordChar = false;
                    break;
                default:
                    txtSetPassword.UseSystemPasswordChar = true;
                    txtConfirmPassword.UseSystemPasswordChar = true;
                    break;


            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void signUP_Load(object sender, EventArgs e)
        {

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormLogin.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(this.txtName.Text.Length>0 && this.dtmDOB.Text.Length>0 && this.txtGender.Text.Length>0 && this.txtEmail.Text.Length>0 && this.txtSetPassword.Text.Length>0 && this.txtMobile.Text.Length > 0 && this.cmbRole.Text.Length>0 && this.txtSetPassword.Text == this.txtConfirmPassword.Text)
            {
                if (cmbRole.Text == "Staff") 
                {
                    
                    string Query1 = @"Select * from [Flavours Haven].[dbo].[User] where Role like 'staff';";
                    DataTable dst = this.Da.ExecuteQueryTable(Query1);
                    int total = dst.Rows.Count;
                    string id = "S-" + (total + 1).ToString();
                    string Query2 = @"insert into [Flavours Haven].[dbo].[SignUp_Request] values('" + id + "','" + this.txtName.Text + "','" + this.dtmDOB.Text + "','" + this.txtGender.Text + "','" + this.txtEmail.Text + "','" + this.txtSetPassword.Text + "','" + this.txtMobile.Text + "','" + this.cmbRole.Text + "');";
                    int cnt = Da.ExecuteDMLQuery(Query2);
                    if (cnt > 0)
                    {
                        MessageBox.Show("SignUp Was Successful & Approve request is sent to Admin for STAFF ID : "+id);
                    }
                    else
                    {
                        MessageBox.Show("Please Provide Correct Information");
                    }
                }
                else
                {
                    string Query1 = @"Select * from [Flavours Haven].[dbo].[User] where Role like 'customer';";
                    DataTable dst = this.Da.ExecuteQueryTable(Query1);
                    int total = dst.Rows.Count;
                    string id = "C-" + (total + 1).ToString();
                    string Query2 = @"insert into [Flavours Haven].[dbo].[User] values('" + id + "','" + this.txtName.Text + "','" + this.dtmDOB.Text + "','" + this.txtGender.Text + "','" + this.txtEmail.Text + "','" + this.txtSetPassword.Text + "','" + this.txtMobile.Text + "','" + this.cmbRole.Text + "');";
                    int cnt = Da.ExecuteDMLQuery(Query2);
                    if (cnt > 0)
                    {
                        MessageBox.Show("SignUp Was Successful and your CUSTOMER ID is : "+ id);
                    }
                    else
                    {
                        MessageBox.Show("Please Provide Correct Information");
                    }
                }
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ResetControl();
        }
        void ResetControl()
        {
            txtName.Clear();
            dtmDOB.Value = DateTime.Today;
            txtGender.Clear();
            txtEmail.Clear();
            txtSetPassword.Clear();
            txtConfirmPassword.Clear();
            txtMobile.Clear();
        }
    }
}
