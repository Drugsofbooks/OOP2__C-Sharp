﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Flavours_Haven
{
    public partial class adminDashboard : Form
    {
        private staffInformation StaffInformation;
        private homePage HomePage;
        private approveRequest ApproveRequest;
        private formLogin FormLogin;
        public adminDashboard()
        {
            StaffInformation = new staffInformation(this);
            HomePage = new homePage(this);
            ApproveRequest = new approveRequest(this);
            FormLogin = new formLogin(this);
            InitializeComponent();
        }
        public adminDashboard(formLogin FormLogin)
        {
            this.FormLogin = FormLogin;
            HomePage = new homePage(this);
            ApproveRequest = new approveRequest(this);
            FormLogin = new formLogin(this);
            StaffInformation = new staffInformation(this);
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }


        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }


        private void adminDashboard_Load(object sender, EventArgs e)
        {

        }

        private void btnApproveRequest_Click(object sender, EventArgs e)
        {
            this.Hide();
            ApproveRequest.Show();
        }

        private void btnHomePage_Click(object sender, EventArgs e)
        {
            this.Hide();
            HomePage.Show();
        }

       

        private void btnBack_Click(object sender, EventArgs e)
        {
        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormLogin.Show();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {

        }

        private void btnStaffInformation_Click(object sender, EventArgs e)
        {
            this.Hide();
            StaffInformation.Show();
        }
    }
}
