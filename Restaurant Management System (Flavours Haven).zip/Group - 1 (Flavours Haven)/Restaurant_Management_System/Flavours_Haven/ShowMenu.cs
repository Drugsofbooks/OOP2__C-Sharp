﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Flavours_Haven
{
    public partial class showMenu : Form
    {
        private menuBurger MenuBurger;
        private menuBiriyani MenuBiriyani;
        private menuPizza MenuPizza;
        private menuDrinks MenuDrinks;
        private customerDashboard CustomerDasboard;
        private string Username;
        public showMenu()
        {
            InitializeComponent();
        }
        public showMenu(customerDashboard CustomerDasboard, string username)
        {
            
            this.CustomerDasboard = CustomerDasboard;
            this.Username = username;
            InitializeComponent();
        }

        private void showMenu_Load(object sender, EventArgs e)
        {

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            CustomerDasboard.Show();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {

        }


        private void btnDrinks_Click(object sender, EventArgs e)
        {
        
            MenuDrinks = new menuDrinks(this, Username);
            this.Hide();
            MenuDrinks.Show();
        }

        private void btnPizza_Click(object sender, EventArgs e)
        {
            MenuPizza = new menuPizza(this, Username);
            this.Hide();
            MenuPizza.Show();

        }

        private void btnBiriyani_Click(object sender, EventArgs e)
        {

            MenuBiriyani = new menuBiriyani(this, Username);
            this.Hide();
            MenuBiriyani.Show();
        }

        private void btnBurger_Click(object sender, EventArgs e)
        {
            MenuBurger = new menuBurger(this, Username);
            this.Hide();
            MenuBurger.Show();
        }
    }
}
