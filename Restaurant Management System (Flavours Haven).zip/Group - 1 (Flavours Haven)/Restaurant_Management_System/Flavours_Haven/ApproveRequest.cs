﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Flavours_Haven
{
    public partial class approveRequest : Form
    {
        private adminDashboard AdminDashboard;
        private Data_Access Da { get; set; }
        public approveRequest()
        {
            Da = new Data_Access();
            InitializeComponent();
            populateGrid();
        }
        private void populateGrid()
        {
            this.dgvSignUpRequest.DataSource = "";
            string query = "Select * from [Flavours Haven].[dbo].[SignUp_Request];";
            DataTable dst = this.Da.ExecuteQueryTable(query);
            this.dgvSignUpRequest.DataSource = dst;

        }
        public approveRequest(adminDashboard AdminDashboard)
        {
            Da = new Data_Access();
            this.AdminDashboard = AdminDashboard;
            InitializeComponent();
            populateGrid();
          
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            AdminDashboard.Show();
        }

        private void dgvSignUpRequest_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            this.txtId.Text = dgvSignUpRequest.Rows[e.RowIndex].Cells["Id"].FormattedValue.ToString();
            this.txtName.Text = dgvSignUpRequest.Rows[e.RowIndex].Cells["Name"].FormattedValue.ToString();
            this.txtDOB.Text = dgvSignUpRequest.Rows[e.RowIndex].Cells["DOB"].FormattedValue.ToString();
            this.txtGender.Text = dgvSignUpRequest.Rows[e.RowIndex].Cells["Gender"].FormattedValue.ToString();
            this.txtEmail.Text = dgvSignUpRequest.Rows[e.RowIndex].Cells["Email"].FormattedValue.ToString();
            this.txtPassword.Text = dgvSignUpRequest.Rows[e.RowIndex].Cells["Password"].FormattedValue.ToString();
            this.txtMobile.Text = dgvSignUpRequest.Rows[e.RowIndex].Cells["Mobile"].FormattedValue.ToString();
        }
        private void clear()
        {
            this.txtId.Text = "";
            this.txtName.Text = "";
            this.txtDOB.Text = "";
            this.txtGender.Text = "";
            this.txtEmail.Text = "";
            this.txtPassword.Text = "";
            this.txtMobile.Text = "";
        }

        private void btnAccept_Click(object sender, EventArgs e)
        {
            if (this.txtId.Text.Length > 0)
            {
                string query = "delete from [Flavours Haven].[dbo].[SignUp_Request] where id = '" + this.txtId.Text + "';";
                int cnt = Da.ExecuteDMLQuery(query);
                if (cnt > 0)
                {
                    MessageBox.Show("Sign Up Request Accepted for the STAFF ID : " + this.txtId.Text);
                    string Query2 = @"insert into [Flavours Haven].[dbo].[User] values('" + this.txtId.Text + "','" + this.txtName.Text + "','" + this.txtDOB.Text + "','" + this.txtGender.Text + "','" + this.txtEmail.Text + "','" + this.txtPassword.Text + "','" + this.txtMobile.Text + "','" + "Staff');";
                    int a = Da.ExecuteDMLQuery(Query2);
                    if (a > 0)
                    {
                        MessageBox.Show("Sign Up Request Accepted for the STAFF ID : " + this.txtId.Text) ;
                        populateGrid();
                        clear();
                    }
                    else
                    {
                        MessageBox.Show("Invalid Operation");
                    }
                }
                else
                {
                    MessageBox.Show("Invalid Operation");
                }

            }
            else
            {
                MessageBox.Show("Select First");
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            if (this.txtId.Text.Length > 0)
            {
                string query = "delete from [Flavours Haven].[dbo].[SignUp_Request] where id = '" + this.txtId.Text + "';";
                int cnt = Da.ExecuteDMLQuery(query);
                if (cnt > 0)
                {
                    MessageBox.Show("Sign Up Request Canceled for the STAFF ID : " + this.txtId.Text);
                    populateGrid();
                    clear();
                }
                else
                {
                    MessageBox.Show("Invalid Operation");
                }

            }
            else
            {
                MessageBox.Show("Select First");
            }
        }

        private void txtId_TextChanged(object sender, EventArgs e)
        {

        }

        private void approveRequest_Load(object sender, EventArgs e)
        {

        }
    }
}
