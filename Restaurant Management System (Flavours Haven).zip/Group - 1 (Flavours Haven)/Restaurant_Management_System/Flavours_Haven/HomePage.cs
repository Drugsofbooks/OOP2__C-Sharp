﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Flavours_Haven
{
    public partial class homePage : Form
    {
        private aboutUs AboutUs;
        private adminDashboard AdminDashboard;
        private staffDashboard StaffDashboard;
        private customerDashboard CustomerDasboard;
        public homePage()
        {
            AboutUs = new aboutUs(this);
            InitializeComponent();
        }
        public homePage(adminDashboard AdminDashboard)
        {
            AboutUs = new aboutUs(this);
            this.AdminDashboard = AdminDashboard;
            InitializeComponent();
        }
        public homePage(staffDashboard StaffDashboard)
        {
            AboutUs = new aboutUs(this);
            this.StaffDashboard = StaffDashboard;
            InitializeComponent();
        }
        public homePage(customerDashboard CustomerDasboard)
        {
            AboutUs = new aboutUs(this);
            this.CustomerDasboard = CustomerDasboard;
            InitializeComponent();
        }
        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void homePage_Load(object sender, EventArgs e)
        {

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide(); 
            if(this.StaffDashboard != null)this.StaffDashboard.Show();
            if(this.AdminDashboard != null)this.AdminDashboard.Show();
            if(this.CustomerDasboard != null)this.CustomerDasboard.Show();
        }

        private void btnAboutUs_Click(object sender, EventArgs e)
        {
            this.Hide();
            AboutUs.Show();
        }
    }
}
