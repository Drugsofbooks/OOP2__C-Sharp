﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Flavours_Haven
{
    public partial class menuBiriyani : Form
    {
        private orderCart OrderCart;
        private showMenu ShowMenu;
        private string Username;
        public menuBiriyani()
        {
            this.ShowMenu = new showMenu();
            InitializeComponent();
        }
        public menuBiriyani(showMenu ShowMenu, string username)
        {
            this.Username = username;
            this.ShowMenu = ShowMenu;
            InitializeComponent();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            ShowMenu.Show();
        }

        private void btnOrderChickenBiriyani_Click(object sender, EventArgs e)
        {
            this.Hide();
            OrderCart = new orderCart(this, Username, "Chicken Biriyani", 300);
            OrderCart.Show();

        }

        private void btnOrderBeefBiriyani_Click(object sender, EventArgs e)
        {
            this.Hide();
            OrderCart = new orderCart(this, Username, "Beef Biriyani", 350);
            OrderCart.Show();
        }
    }
}
