﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Flavours_Haven
{
    public partial class menuPizza : Form
    {
        private orderCart OrderCart;
        private showMenu ShowMenu;
        private string Username;
        public menuPizza()
        {
            this.ShowMenu = new showMenu();
            InitializeComponent();
        }
        public menuPizza(showMenu ShowMenu, string username)
        {
            this.Username = username;
            this.ShowMenu = ShowMenu;
            InitializeComponent();
        }
        private void menuPizza_Load(object sender, EventArgs e)
        {

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            ShowMenu.Show();

        }

        private void btnOrderCheesePizza_Click(object sender, EventArgs e)
        {
            this.Hide();
            OrderCart = new orderCart(this, Username, "Cheese Pizza", 500);
            OrderCart.Show();
        }

        private void btnOrderSpicyPizza_Click(object sender, EventArgs e)
        {
            this.Hide();
            OrderCart = new orderCart(this, Username, "Hot & Spicy Pizza", 450);
            OrderCart.Show();
        }
    }
}
