﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Flavours_Haven
{
    public partial class orderList : Form
    {
        private staffDashboard StaffDashboard;
        private Data_Access Da { get; set; }
        public orderList()
        {
            Da = new Data_Access();
            InitializeComponent();
        }
        private void populateGrid()
        {
            string query = "Select * from [Flavours Haven].[dbo].[OrderMain];";
            DataTable dst = this.Da.ExecuteQueryTable(query);
            this.dgvOrders.DataSource = dst;
            
        }
        public orderList(staffDashboard StaffDashboard)
        {
            Da = new Data_Access();
            this.StaffDashboard = StaffDashboard;
            InitializeComponent();
            populateGrid();
        }

        private void orderList_Load(object sender, EventArgs e)
        {

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            StaffDashboard.Show();
        }

        private void dgvOrders_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            string a, b;
            this.txtOrderId.Text = dgvOrders.Rows[e.RowIndex].Cells["Id"].FormattedValue.ToString();
            this.txtCustomerId.Text = dgvOrders.Rows[e.RowIndex].Cells["UserId"].FormattedValue.ToString();
            this.txtItemName.Text = dgvOrders.Rows[e.RowIndex].Cells["Category"].FormattedValue.ToString();
            a = this.txtQuantity.Text = dgvOrders.Rows[e.RowIndex].Cells["Quantity"].FormattedValue.ToString();
            b = this.txtTotalPrice.Text = dgvOrders.Rows[e.RowIndex].Cells["Price"].FormattedValue.ToString();
            this.txtItemPrice.Text = (Convert.ToInt32(b) / Convert.ToInt32(a)).ToString();
        }
        private void clear()
        {
            this.txtOrderId.Text = "";
            this.txtCustomerId.Text = "";
            this.txtItemName.Text = "";
            this.txtQuantity.Text = "";
            this.txtTotalPrice.Text = "";
            this.txtItemPrice.Text = "";
        }
        private void txtOrderId_TextChanged(object sender, EventArgs e)
        {


        }

        private void txtCustomerId_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnAccept_Click(object sender, EventArgs e)
        {
            if (this.txtOrderId.Text.Length > 0)
            {
                string query = "delete from [Flavours Haven].[dbo].[OrderMain] where id = '"+this.txtOrderId.Text+ "';";
                int cnt = Da.ExecuteDMLQuery(query);
                if (cnt > 0)
                {
                    MessageBox.Show("Order Is Accepted For "+this.txtCustomerId.Text + "\n Payment is Successful !");
                    populateGrid();
                    clear();
                }
                else
                {
                    MessageBox.Show("Invalid Operation");
                }

            }
            else
            {
                MessageBox.Show("Select First");
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            if (this.txtOrderId.Text.Length > 0)
            {
                string query = "delete from [Flavours Haven].[dbo].[OrderMain] where id = '" + this.txtOrderId.Text + "';";
                int cnt = Da.ExecuteDMLQuery(query);
                if (cnt > 0)
                {
                    MessageBox.Show("Order Is Cancelled For " + this.txtCustomerId.Text + "\n Payment refund is Successful !");
                    populateGrid();
                    clear();
                }
                else
                {
                    MessageBox.Show("Invalid Operation");
                }

            }
            else
            {
                MessageBox.Show("Select First");
            }
        }

        private void dgvOrders_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
