﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Flavours_Haven
{
    public partial class customerDashboard : Form
    {
        private formLogin FormLogin;
        private homePage HomePage;
        private showMenu ShowMenu;
        private string Username;
        public customerDashboard()
        {
            HomePage = new homePage(this);
            InitializeComponent();
        }
        public customerDashboard(formLogin FormLogin, string username)
        {
            this.Username = username;
            HomePage = new homePage(this);
            this.FormLogin = FormLogin;
            InitializeComponent();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void customerDashboard_Load(object sender, EventArgs e)
        {

        }

        private void btnHomePage_Click(object sender, EventArgs e)
        {
            this.Hide();
            HomePage.Show();
        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormLogin.Show();
        }

        private void btnShowMenu_Click(object sender, EventArgs e)
        {
            this.Hide();
            ShowMenu = new showMenu(this, Username);
            ShowMenu.Show();
        }
    }
}
