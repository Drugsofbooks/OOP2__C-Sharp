﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Flavours_Haven
{
    public partial class orderCart : Form
    {
        private menuBurger MenuBurger;
        private menuBiriyani MenuBiriyani;
        private menuPizza MenuPizza;
        private menuDrinks MenuDrinks;
        private string Username, itemname;
        private int price;
        private Data_Access Da;
        public orderCart()
        {
            this.MenuBurger = new menuBurger();
            this.MenuBiriyani = new menuBiriyani();
            this.MenuPizza = new menuPizza();
            this.MenuDrinks = new menuDrinks();
            InitializeComponent();
        }
        public orderCart(menuDrinks MenuDrinks, string username, string itemname, int price)
        {
            this.MenuDrinks = MenuDrinks;
            this.Username = username;
            this.itemname = itemname;
            this.price = price;
            Da = new Data_Access();
            InitializeComponent();
        }
        public orderCart(menuBurger MenuBurger, string username, string itemname, int price)
        {
            this.MenuBurger = MenuBurger;
            this.Username = username;
            this.itemname = itemname;
            this.price = price;
            Da = new Data_Access();
            InitializeComponent();
        }
        public orderCart(menuBiriyani MenuBiriyani, string username, string itemname, int price)
        {
            this.MenuBiriyani = MenuBiriyani;
            this.Username = username;
            this.itemname = itemname;
            this.price = price;
            Da = new Data_Access();
            InitializeComponent();
        }
        public orderCart(menuPizza MenuPizza, string username, string itemname, int price)
        {
            this.MenuPizza = MenuPizza;
            this.Username = username;
            this.itemname = itemname;
            this.price = price;
            Da = new Data_Access();
            InitializeComponent();
        }
        public orderCart(menuPizza MenuPizza)
        {
            this.MenuPizza = MenuPizza;
            InitializeComponent();
        }
        public orderCart(menuBiriyani MenuBiriyani)
        {
            this.MenuBiriyani = MenuBiriyani;
            InitializeComponent();
        }
        public orderCart(menuBurger MenuBurger)
        {
            this.MenuBurger = MenuBurger;
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int quantity = Convert.ToInt32(this.txtQuantity.Text);
            int total =  quantity * this.price;
            string query = @"insert into [Flavours Haven].[dbo].[OrderMain] values('"+ this.itemname + "','" + this.Username + "'," + total + "," + quantity + ");";
            int cnt = Da.ExecuteDMLQuery(query);
            if (cnt > 0)
            {
                MessageBox.Show("Order Successful "+ "& Your generated bill is : "+total+" Taka"+"\n                  Thank you for your payment !");

            }
            else
            {
                MessageBox.Show("Order Unsuccessful");
            }
        }

        private void orderCart_Load(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            if (this.MenuDrinks != null) this.MenuDrinks.Show();
            if (this.MenuPizza != null) this.MenuPizza.Show();
            if (this.MenuBiriyani != null) this.MenuBiriyani.Show();
            if (this.MenuBurger != null) this.MenuBurger.Show();
        }
    }
}
