﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Flavours_Haven
{
    public partial class staffDashboard : Form
    {
        private formLogin FormLogin;
        private homePage HomePage;
        private orderList OrderList;
        private staffProfile StaffProfile;
        private string Username;
        public staffDashboard()
        {
            HomePage = new homePage(this);
            OrderList = new orderList(this);
            InitializeComponent();
        }
        public staffDashboard(formLogin FormLogin, string Username)
        {
            OrderList = new orderList(this);
            HomePage = new homePage(this);
            this.FormLogin = FormLogin;
            this.Username = Username;
            InitializeComponent();
        }

        private void staffDashboard_Load(object sender, EventArgs e)
        {

        }

        private void btnHomePage_Click(object sender, EventArgs e)
        {
            this.Hide();
            HomePage.Show();
        }

        private void btnOrderLIst_Click(object sender, EventArgs e)
        {
            this.Hide();
            OrderList.Show();
        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormLogin.Show();
        }

        private void btnprofile_Click(object sender, EventArgs e)
        {
            this.Hide();
            StaffProfile = new staffProfile(this, Username);

            StaffProfile.Show();

        }
    }
}
