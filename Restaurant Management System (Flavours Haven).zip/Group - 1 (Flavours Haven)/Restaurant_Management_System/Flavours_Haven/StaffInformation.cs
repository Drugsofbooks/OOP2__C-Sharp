﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Flavours_Haven
{
    public partial class staffInformation : Form
    {
        private adminDashboard AdminDashboard;
        private Data_Access Da { get; set; }
        public staffInformation()
        {
            Da = new Data_Access();
            this.AdminDashboard = new adminDashboard();
            InitializeComponent();
            populateGrid();
        }
        private void populateGrid()
        {
            this.dgvStaffInformation.DataSource = "";
            string query = @"Select * from [Flavours Haven].[dbo].[User] where Role like 'Staff';";
            DataTable dst = this.Da.ExecuteQueryTable(query);
            this.dgvStaffInformation.DataSource = dst;

        }
        public staffInformation(adminDashboard AdminDashboard)
        {
            Da = new Data_Access();
            this.AdminDashboard = AdminDashboard;
            InitializeComponent();
            populateGrid();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            AdminDashboard.Show();
        }

        private void dgvStaffInformation_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            this.txtId.Text = dgvStaffInformation.Rows[e.RowIndex].Cells["Id"].FormattedValue.ToString();
            this.txtName.Text = dgvStaffInformation.Rows[e.RowIndex].Cells["Name"].FormattedValue.ToString();
            this.dtmDOB.Text = dgvStaffInformation.Rows[e.RowIndex].Cells["DOB"].FormattedValue.ToString();
            this.txtGender.Text = dgvStaffInformation.Rows[e.RowIndex].Cells["Gender"].FormattedValue.ToString();
            this.txtEmail.Text = dgvStaffInformation.Rows[e.RowIndex].Cells["Email"].FormattedValue.ToString();
            this.txtMobile.Text = dgvStaffInformation.Rows[e.RowIndex].Cells["Mobile"].FormattedValue.ToString();
        }
        private void clear()
        {
            this.txtId.Text = "";
            this.txtName.Text = "";
            this.dtmDOB.Text = "";
            this.txtGender.Text = "";
            this.txtEmail.Text = "";
            this.txtMobile.Text = "";
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (this.txtId.Text.Length > 0)
            {
                string query = "delete from [Flavours Haven].[dbo].[User] where id = '" + this.txtId.Text + "';";
                int cnt = Da.ExecuteDMLQuery(query);
                if (cnt > 0)
                {
                    MessageBox.Show("STAFF ID : " + this.txtId.Text + " is Deleted");
                    populateGrid();
                    clear();
                }
                else
                {
                    MessageBox.Show("Invalid Operation");
                }

            }
            else
            {
                MessageBox.Show("Select First");
            }
        }
    }
}
