﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Flavours_Haven
{
    public partial class staffProfile : Form
    {
        private staffDashboard StaffDashboard;
        private Data_Access Da { get; set; }
        private string Username;
        public staffProfile()
        {
            Da = new Data_Access();
            this.StaffDashboard = new staffDashboard();
            InitializeComponent();
        }
        public staffProfile(staffDashboard StaffDashboard, string username)
        {
            this.Username = username;
            this.Da = new Data_Access();
            string QUERY = @"Select * from [Flavours Haven].[dbo].[User] where Id like '" + Username + "';";
            var user = Da.ExecuteQueryTable(QUERY);
            InitializeComponent();
            this.lblId.Text = user.Rows[0][0].ToString();
            this.txtName.Text = user.Rows[0][1].ToString();
            this.dtmDOB.Text = user.Rows[0][2].ToString();
            this.txtGender.Text = user.Rows[0][3].ToString();
            this.txtEmail.Text = user.Rows[0][4].ToString();
            this.txtMobile.Text = user.Rows[0][6].ToString();
            this.StaffDashboard = StaffDashboard;
            
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            StaffDashboard.Show();

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {

            string QUERY = @"Select * from [Flavours Haven].[dbo].[User] where Id like '"+Username+"';";
            var user = Da.ExecuteQueryTable(QUERY);
            if (this.txtName.Text.Length > 0 && this.dtmDOB.Text.Length > 0 && this.txtGender.Text.Length > 0 && this.txtEmail.Text.Length > 0 && this.txtMobile.Text.Length > 0)
            {
                string Query2 = @"update [Flavours Haven].[dbo].[User] set Name = '" + this.txtName.Text + @"',DOB = '" + this.dtmDOB.Text + @"',Gender = '" + this.txtGender.Text + @"',Email = '" + this.txtEmail.Text + @"',Password = '" + user.Rows[0][5].ToString()+ @"',Mobile = '" + this.txtMobile.Text + @"' where Id = '" + Username + "';";
                int cnt = Da.ExecuteDMLQuery(Query2);
                if (cnt > 0)
                {
                    MessageBox.Show("Update Was Successful");
                    this.lblId.Text = "";
                    this.txtName.Text = "";
                    this.dtmDOB.Text = "";
                    this.txtGender.Text = "";
                    this.txtEmail.Text = "";
                    this.txtMobile.Text = "";
                }
                else
                {
                    MessageBox.Show("Please Provide Correct Information");
                }
            }
        }
    }
}
