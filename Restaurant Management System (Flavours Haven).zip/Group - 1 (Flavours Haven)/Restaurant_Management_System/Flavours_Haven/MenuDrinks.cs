﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Flavours_Haven
{
    public partial class menuDrinks : Form
    {
        private orderCart OrderCart;
        private showMenu ShowMenu;
        private string Username;
        public menuDrinks()
        {
            this.ShowMenu = new showMenu();
            InitializeComponent();
        }
        public menuDrinks(showMenu ShowMenu, string username)
        {
            this.Username = username;
            this.ShowMenu = ShowMenu;
            InitializeComponent();
        }
        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            ShowMenu.Show();
        }

        private void btnOrderPepsi_Click(object sender, EventArgs e)
        {
            this.Hide();
            OrderCart = new orderCart(this, Username, "Pepsi", 50);
            OrderCart.Show();

        }

        private void btnOredr7up_Click(object sender, EventArgs e)
        {
            this.Hide();
            OrderCart = new orderCart(this, Username, "7Up", 50);
            OrderCart.Show();
        }
    }
}
