﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceExample
{
    class Employee
    {
        private String name;
        private int age;

        public Employee() { }

        public Employee(String name , int age) 
        {
            this.name = name;
            this.age = age;
        }

        public String Name
        {
            get { return name; }
            set { name = value; }
        }

        public int Age
        {
            get { return age; }
            set { age = value; }
        }

        public void showInfo()
        {
            Console.WriteLine("Name is       : " + name);
            Console.WriteLine("Age is        : " + age);
        }
    }

    class PermanentEmployee : Employee
    {
        private int salary;

        public PermanentEmployee(){}

        public PermanentEmployee(String name , int age , int salary) : base(name , age)
        {
            this.salary = salary;
        }

        public int Salary
        {
            get { return salary; }
            set { salary = value; }
        }

        public void showInfo1()
        {
            Console.WriteLine("Salary is     : " + salary);
            Console.WriteLine("-------------------------");
        }
    }

    class ContractEmployee : Employee
    {
        private int hourlyPay;

        public ContractEmployee() { }

        public ContractEmployee(String name , int age , int hourlyPay) : base (name , age)
        {
            this.hourlyPay = hourlyPay;
        }

        public int Pay
        {
            get { return hourlyPay; }
            set { hourlyPay = value; }
        }

        public void showInfo2()
        {
            Console.WriteLine("Hourly Pay is : " + hourlyPay);
            Console.WriteLine("-------------------------");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            PermanentEmployee p1 = new PermanentEmployee();
            p1.Name = "Abid";
            p1.Age = 22;
            p1.Salary = 50000;
            p1.showInfo();
            p1.showInfo1();

            PermanentEmployee p2 = new PermanentEmployee("Rawaha", 25 , 60000);
            p2.showInfo();
            p2.showInfo1();

            ContractEmployee c1 = new ContractEmployee();
            c1.Name = "Nazir";
            c1.Age = 20;
            c1.Pay = 70000;
            c1.showInfo();
            c1.showInfo2();

            ContractEmployee c2 = new ContractEmployee("Anik" , 28 , 90000);
            c2.showInfo();
            c2.showInfo2();

            Console.ReadLine();
        }
    }
}
