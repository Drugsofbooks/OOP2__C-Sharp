﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task___5
{
    class Program
    {
        static void Main(string[] args)
        {
            int number , result;

            Console.Write("Enter your number : ");
            number = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Multiplication table of your number is : ");
            Console.WriteLine("-----------------------------------------");

            for (int i=0; i<=10; i++)
            {
                result = number * i;
                Console.Write(+number);
                Console.Write(" X ");
                Console.Write(+i);
                Console.Write(" = ");
                Console.Write(+result);
                Console.WriteLine();
            }

            Console.WriteLine("-----------------------------------------");
            Console.ReadLine();
        }
    }
}
