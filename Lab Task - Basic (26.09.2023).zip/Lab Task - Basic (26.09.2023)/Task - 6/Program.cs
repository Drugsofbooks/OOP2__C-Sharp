﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task___6
{
    class Program
    {
        static void Main(string[] args)
        {
            int sum = 0 , num;

            Console.WriteLine("Enter 5 integers");

            for (int i = 0; i < 5; i++)
            {
                Console.Write("Integer value "+(i+1));
                Console.Write(" is : ");
                num = Convert.ToInt32(Console.ReadLine());

                sum += num;
            }

            double avg = (double)sum / 5;

            Console.WriteLine("The average is : " +avg);
            Console.ReadLine();
        }
    }
}
