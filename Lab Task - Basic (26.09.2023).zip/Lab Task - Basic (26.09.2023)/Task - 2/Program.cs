﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task___2
{
    class Program
    {
        static void Main(string[] args)
        {
            double tax, total, price , kg;

            Console.Write("Enter the price of potatoes WITHOUT TAX : ");
            price = Convert.ToDouble(Console.ReadLine());

            Console.Write("Enter how many KILOGRAMS of potatoes you want : ");
            kg = Convert.ToDouble(Console.ReadLine());

            Console.Write("Enter the TAX RATE in percent : ");
            tax = Convert.ToDouble(Console.ReadLine());

            total = price * kg * (1 + tax / 100);

            Console.WriteLine();
            Console.WriteLine("Price WITHOUT TAX is : " +(price*kg));
            Console.WriteLine("TAX rate is : " +(tax/100));
            Console.WriteLine("Price WITH TAX is : " + total);
            Console.ReadLine();
        }
    }
}
