﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task___1
{
    class Program
    {
        static void Main(string[] args)
        {
            double score;

            Console.Write("Enter your score : ");
            score = Convert.ToDouble(Console.ReadLine());

            if (90 <= score && score <= 100)
            {
                Console.WriteLine("Your Grade is : A+");
            }
            else if (80 <= score && score < 90)
            {
                Console.WriteLine("Your Grade is : A");
            }
            else if (70 <= score && score < 80)
            {
                Console.WriteLine("Your Grade is : B");
            }
            else if (60 <= score && score < 70)
            {
                Console.WriteLine("Your Grade is : C");
            }
            else if (50 <= score && score < 60)
            {
                Console.WriteLine("Your Grade is : D");
            }
            else if (0 <= score && score < 50)
            {
                Console.WriteLine("Your Grade is : F");
            }
            else
            {
                Console.WriteLine("Your score number is INVALID");
            }

            Console.ReadLine();
        }
    }
}
