﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task___4
{
    class Program
    {
        static void Main(string[] args)
        {
            int totalDays , year , week , day;

            Console.Write("Enter the number of days : ");
            totalDays = Convert.ToInt32(Console.ReadLine());

            year = totalDays / 365;
            week = (totalDays % 365) / 7;
            day = totalDays - (year * 365) - (week * 7);

            Console.WriteLine("Number of Years : "+year);
            Console.WriteLine("Number of Weeks : "+week);
            Console.WriteLine("Number of Days : "+day);

            Console.ReadLine();
        }
    }
}
