﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task___3
{
    class Program
    {
        static void Main(string[] args)
        {
            double a, b, c, sum;

            Console.Write("Enter your first angle : ");
            a = Convert.ToDouble(Console.ReadLine());

            Console.Write("Enter your second angle : ");
            b = Convert.ToDouble(Console.ReadLine());

            Console.Write("Enter your third angle : ");
            c = Convert.ToDouble(Console.ReadLine());

            sum = a + b + c;

            if (sum == 180)
            {
                Console.Write("You can from a TRIANGLE");
            }
            else
            {
                Console.Write("Your angles are INVALID");
            }

            Console.ReadLine();
        }
    }
}
