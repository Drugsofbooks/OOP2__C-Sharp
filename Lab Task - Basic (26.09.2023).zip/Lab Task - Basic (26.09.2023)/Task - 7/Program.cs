﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task___7
{
    class Program
    {
        static void Main(string[] args)
        {
            double a, b, result;
            char option;

            Console.Write("Enter your first number : ");
            a = Convert.ToDouble(Console.ReadLine());

            Console.Write("Enter your second number : ");
            b = Convert.ToDouble(Console.ReadLine());

            Console.Write("Enter your options (+ , - , * , /) : ");
            option = Convert.ToChar(Console.ReadLine());

            switch (option)
            {
                case '+':
                    result = a + b;
                    Console.WriteLine("Addition is : " + result);
                    break;

                case '-':
                    result = a - b;
                    Console.WriteLine("Subtraction is : " + result);
                    break;

                case '*':
                    result = a * b;
                    Console.WriteLine("Multiplication is : " + result);
                    break;

                case '/':
                    if (b != 0)
                    {
                        result = a / b;
                        Console.WriteLine("Division is : " + result);
                    }
                    else
                    {
                        Console.WriteLine("Division is ERROR");
                    }
                    break;

                default:
                    Console.WriteLine("Option is INVALID");
                    break;
            }

            Console.ReadLine();
        }
    }
}
