﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test_Interface_1
{
    public interface BasicCalculatorInterface
    {
        int Sum(int x, int y);
        int Sub(int x, int y);
        int Multiplication(int x, int y);
        int Division(int x, int y);
    }

    public interface ScientificCalculatorInterface
    {
        int XtoY(int x, int y);
        int Fact(int x);
    }

    public class Calculator : BasicCalculatorInterface, ScientificCalculatorInterface
    {
        public int Sum(int x, int y)
        {
            return x + y;
        }

        public int Sub(int x, int y)
        {
            return x - y;
        }

        public int Multiplication(int x, int y)
        {
            return x * y;
        }

        public int Division(int x, int y)
        {
            if (y != 0)
            {
                return x / y;
            }
            else
            {
                Console.WriteLine("Cannot divide by zero.");
                return 0;
            }
        }

        public int XtoY(int x, int y)
        {
            return (int)Math.Pow(x, y);
        }

        public int Fact(int x)
        {
            if (x == 0 || x == 1)
            {
                return 1;
            }
            else
            {
                return x * Fact(x - 1);
            }
        }
    }

    class Program
    {
        static void Main()
        {
            Calculator calculator = new Calculator();

            Console.WriteLine("Two numbers are      : " + 6 + " & " + 3);

            Console.WriteLine("Addition is          : " + calculator.Sum(6, 3));
            Console.WriteLine("Subtraction is       : " + calculator.Sub(6, 3));
            Console.WriteLine("Multiplication is    : " + calculator.Multiplication(6, 3));
            Console.WriteLine("Division is          : " + calculator.Division(6, 3));

            Console.WriteLine("Power calculation is : " + calculator.XtoY(6, 3));
            Console.WriteLine("Factorial is         : " + calculator.Fact(6));

            Console.ReadLine();
        }
    }
}
