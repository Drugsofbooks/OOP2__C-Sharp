﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test_Interface_2
{
    public interface BasicBankingInterface
    {
        bool Deposit(int amount);
        bool Withdraw(int amount);
    }

    public enum AccountType
    {
        Current,
        Savings,
        Overdraft
    }

    public abstract class BankAccount : BasicBankingInterface
    {
        protected int Balance;

        public bool Deposit(int amount)
        {
            Balance += amount;
            Console.WriteLine($"Deposited: {amount} | Current Balance: {Balance}");
            return true;
        }

        public abstract bool Withdraw(int amount);
    }

    public class CurrentAccount : BankAccount
    {
        public override bool Withdraw(int amount)
        {
            Balance -= amount;
            Console.WriteLine($"Withdrawn: {amount} | Current Balance: {Balance}");
            return true;
        }
    }

    public class SavingsAccount : BankAccount
    {
        public override bool Withdraw(int amount)
        {
            if (amount <= Balance * 0.8)
            {
                Balance -= amount;
                Console.WriteLine($"Withdrawn: {amount} | Current Balance: {Balance}");
                return true;
            }
            else
            {
                Console.WriteLine("Withdrawal limit exceeded for Savings Account.");
                return false;
            }
        }
    }

    public class OverdraftAccount : BankAccount
    {
        private int overdraftLimit;

        public OverdraftAccount(int overdraftLimit)
        {
            this.overdraftLimit = overdraftLimit;
        }

        public override bool Withdraw(int amount)
        {
            if (amount <= Balance + overdraftLimit)
            {
                Balance -= amount;
                Console.WriteLine($"Withdrawn: {amount} | Current Balance: {Balance}");
                return true;
            }
            else
            {
                Console.WriteLine("Withdrawal limit exceeded for Overdraft Account.");
                return false;
            }
        }
    }

    class Program
    {
        static void Main()
        {
            BankAccount currentAccount = new CurrentAccount();
            BankAccount savingsAccount = new SavingsAccount();
            BankAccount overdraftAccount = new OverdraftAccount(1000);

            currentAccount.Deposit(5000);
            currentAccount.Withdraw(2000);
            Console.WriteLine("---------------------------------------");

            savingsAccount.Deposit(3000);
            savingsAccount.Withdraw(2000);
            Console.WriteLine("---------------------------------------");

            overdraftAccount.Deposit(2000);
            overdraftAccount.Withdraw(2500);

            Console.ReadLine();
        }
    }
}
