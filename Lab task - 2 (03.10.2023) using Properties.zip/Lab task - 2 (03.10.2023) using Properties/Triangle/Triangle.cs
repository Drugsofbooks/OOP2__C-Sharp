﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Triangle
{
    class Triangle
    {
        private int x;
        private int y;
        private int z;
        public Triangle() { }
        public Triangle(int x, int y, int z)
        {
            this.x = x;
            this.y = y;
            this.z = z;
        }

        public int X
        {
            get { return x; }
            set { x = value; }
        }

        public int Y
        {
            get { return y; }
            set { y = value; }
        }

        public int Z
        {
            get { return z; }
            set { z = value; }
        }

        //public void setX(int x) { this.x = x; }
        //public int getX() { return x; }
        //public void setY(int y) { this.y = y; }
        //public int getY() { return y; }
        //public void setZ(int z) { this.z = z; }
        //public int getZ() { return z; }
        
        public void ShowInfo() 
        {
            Console.WriteLine("Triangle sides are : "+x+" , "+y+" , "+z);
        }
        public void TestTriangle()
        {
            if (x==y && y==z)
            {
                Console.WriteLine("Triangle is Equilateral");
                Console.WriteLine("----------------------------------------");
            }
            else if(x==y || y==z || x==z)
            {
                Console.WriteLine("Triangle is Isosceles");
                Console.WriteLine("----------------------------------------");
            }
            else
            {
                Console.WriteLine("Triangle is Scalene");
                Console.WriteLine("----------------------------------------");
            }
        }
    }
}
