﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student
{
    class Student
    {
        private String name;
        private String id;
        private String department;
        private float cgpa;

        public Student() { }
        public Student(String name, String id, String department, float cgpa)
        {
            this.name = name;
            this.id = id;
            this.department = department;
            this.cgpa = cgpa;
        }

        public String Name
        {
            get { return name; }
            set { name = value; }
        }

        public String Id
        {
            get { return id; }
            set { id = value; }
        }

        public String Dept
        {
            get { return department; }
            set { department = value; }
        }

        public float Cgpa
        {
            get { return cgpa; }
            set { cgpa = value; }
        }
        //public void setName(String name) { this.name = name; }
        //public String getName() { return name; }
        //public void setId(String id) { this.id = id; }
        //public String getId() { return id; }
        //public void setDept(String department) { this.department = department; }
        //public String getDept() { return department; }
        //public void setCgpa(float cgpa) { this.cgpa = cgpa; }
        //public float getCgpa() { return cgpa; }
        public void ShowInfo()
        {
            Console.WriteLine("-----------------------------------");
            Console.WriteLine("Name is       : " + name);
            Console.WriteLine("Id is         : " + id);
            Console.WriteLine("Department is : " + department);
            Console.WriteLine("Cgpa is       : " + cgpa);
            Console.WriteLine("-----------------------------------");
        }
    }
}