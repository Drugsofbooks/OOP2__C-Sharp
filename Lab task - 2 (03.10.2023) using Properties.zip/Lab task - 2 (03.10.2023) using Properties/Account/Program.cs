﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Account
{
    class Program
    {
        static void Main()
        {
            /*Account a1 = new Account("Abid Nazir", "2245312", 1000);
            a1.ShowInfo();
            a1.Deposit(500);
            a1.Withdraw(200);*/

            Account a2 = new Account();
            a2.Name = "Abid Nzir";
            //Console.WriteLine(a2.Name);
            a2.Id = "2245321";
            //Console.WriteLine(a2.Id);
            a2.Balance = 1000;
            //Console.WriteLine(a2.Balance);
            a2.ShowInfo();
            Console.ReadLine();
        }
    }
}
