﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClubManagement
{
    class Program
    {
        static void Main(string[] args)
        {
            Cricketer cricketer = new Cricketer(1, "Cricketer", 5000.0, DateTime.Parse("2022-02-22"), 2000, 50);
            cricketer.ShowInfo();

            Console.WriteLine("---------------------------------------");

            Footballer footballer = new Footballer(2, "Footballer", 4000.0, DateTime.Now, 30, 15);
            footballer.ShowInfo();

            Console.ReadLine();
        }
    }
}
