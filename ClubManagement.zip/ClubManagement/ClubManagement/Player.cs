﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClubManagement
{
    class Player
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public double Salary { get; set; }
        public DateTime JoiningDate { get; set; }

        public Player(int id, string name, double salary, DateTime joiningDate)
        {
            Id = id;
            Name = name;
            Salary = salary;
            JoiningDate = joiningDate;
        }

        public virtual void ShowInfo()
        {
            Console.WriteLine("Player ID            : " + Id);
            Console.WriteLine("Player Name          : " + Name);
            Console.WriteLine("Player Salary        : " + Salary);
            Console.WriteLine("Player Joining Date  : " + JoiningDate.ToShortDateString());
        }
    }

}
