﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClubManagement
{
    class Footballer : Player
    {
        public int TotalGoal { get; set; }
        public int TotalAssist { get; set; }

        public Footballer(int id, string name, double salary, DateTime joiningDate, int totalGoal, int totalAssist)
            : base(id, name, salary, joiningDate)
        {
            TotalGoal = totalGoal;
            TotalAssist = totalAssist;
        }

        public override void ShowInfo()
        {
            base.ShowInfo();
            Console.WriteLine("Total Goals          : " + TotalGoal);
            Console.WriteLine("Total Assists        : " + TotalAssist);
        }
    }

}
