﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClubManagement
{
    class Cricketer : Player
    {
        public int TotalRun { get; set; }
        public int TotalWicket { get; set; }

        public Cricketer(int id, string name, double salary, DateTime joiningDate, int totalRun, int totalWicket)
            : base(id, name, salary, joiningDate)
        {
            TotalRun = totalRun;
            TotalWicket = totalWicket;
        }

        public override void ShowInfo()
        {
            base.ShowInfo();
            Console.WriteLine("Total Runs           : " + TotalRun);
            Console.WriteLine("Total Wickets        : " + TotalWicket);
        }
    }

}
