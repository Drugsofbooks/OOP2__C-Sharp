﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
        class Course
        {
            private string courseName;
            private int courseCredit;
            private Student[] listOfStudents;

            public string CourseName
            {
                get { return courseName; }
                set { courseName = value; }
            }

            public int CourseCredit
            {
                get { return courseCredit; }
                set { courseCredit = value; }
            }

            public Course(string courseName, int courseCredit)
            {
                this.courseName = courseName;
                this.courseCredit = courseCredit;
                listOfStudents = new Student[30];
            }

            public void AddStudent(Student student)
            {
                if (listOfStudents.Length < 30)
                {
                    listOfStudents[listOfStudents.Length] = student;
                }
                else
                {
                    Console.WriteLine("Course is full. Cannot enroll more students.");
                }
            }

            public void RemoveStudent(Student student)
            {
                for (int i = 0; i < listOfStudents.Length; i++)
                {
                    if (listOfStudents[i] == student)
                    {
                        listOfStudents[i] = null;
                        break;
                    }
                }
            }

            public void ShowEnrolledStudents()
            {
                Console.WriteLine("Students enrolled in " + courseName + ":");
                foreach (Student student in listOfStudents)
                {
                    if (student != null)
                    {
                        Console.WriteLine(student.Name);
                    }
                }
            }
        }

        class Student
        {
            private string name;
            private string id;
            private Course[] listOfCourses;

            public string Name
            {
                get { return name; }
                set { name = value; }
            }

            public string ID
            {
                get { return id; }
                set { id = value; }
            }

            public Student(string name, string id)
            {
                this.name = name;
                this.id = id;
                listOfCourses = new Course[5];
            }

            public void EnrollInCourse(Course course)
            {
                if (listOfCourses.Length < 5)
                {
                    listOfCourses[listOfCourses.Length] = course;
                    course.AddStudent(this);
                }
                else
                {
                    Console.WriteLine("You are already enrolled in the maximum number of courses.");
                }
            }

            public void DropCourse(Course course)
            {
                for (int i = 0; i < listOfCourses.Length; i++)
                {
                    if (listOfCourses[i] == course)
                    {
                        listOfCourses[i] = null;
                        course.RemoveStudent(this);
                        break;
                    }
                }
            }

            public void ShowEnrolledCourses()
            {
                Console.WriteLine("Courses enrolled by " + name + ":");
                foreach (Course course in listOfCourses)
                {
                    if (course != null)
                    {
                        Console.WriteLine(course.CourseName);
                    }
                }
            }
        }

        class Program
        {
            static void Main()
            {
                Course mathCourse = new Course("Math-01", 3);
                Course physicsCourse = new Course("Physics-01", 3);

                Student student1 = new Student("Abid", "101");
                Student student2 = new Student("Nazir", "102");

                student1.EnrollInCourse(mathCourse);
                student1.EnrollInCourse(physicsCourse);
                student2.EnrollInCourse(physicsCourse);

                mathCourse.ShowEnrolledStudents();            
                physicsCourse.ShowEnrolledStudents();

                student1.ShowEnrolledCourses();                
                student2.ShowEnrolledCourses();

                Console.ReadLine();
            }
        }
}
