﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopManagement
{
    class Program
    {
        static void Main(string[] args)
        {
            PreferredCustomer preferredCustomer = new PreferredCustomer("Abid Nazir", "84 East Basaboo", "016-288-23868", 111, true, 1800.0);
            preferredCustomer.ShowInfo();

            Console.ReadLine();
        }
    }
}
