﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryManagement
{
    class Library
    {
        private string libName;
        private string libAddress;
        private Book[] listOfBook;
        private int totalBook;
        public string LibName
        {
            get { return libName; }
            set { libName = value; }
        }

        public string LibAddress
        {
            get { return libAddress; }
            set { libAddress = value; }
        }

        public Book[] ListOfBook
        {
            get { return listOfBook; }
        }

        public int TotalBook
        {
            get { return totalBook; }
            set { totalBook = value; }
        }

        public Library()
        {
            listOfBook = new Book[100];
        }

        public Library(string name, string address)
        {
            LibName = name;
            LibAddress = address;
            listOfBook = new Book[100];
        }

        public void ShowLibInfo()
        {
            //Console.WriteLine();
            Console.WriteLine("-----------------------------------------");
            //Console.WriteLine();
            Console.WriteLine($"Library Name: {LibName}");
            Console.WriteLine($"Library Address: {LibAddress}");
            Console.WriteLine($"Total Books in Library: {TotalBook}");
           //Console.WriteLine();
            Console.WriteLine("-----------------------------------------");
            //Console.WriteLine();
            Console.WriteLine("List of Books:");
            for (int i = 0; i < TotalBook; i++)
            {
                Console.WriteLine($"Book {i + 1}: {listOfBook[i].BookName}");
            }
            //Console.WriteLine();
            Console.WriteLine("-----------------------------------------");
            //Console.WriteLine();
        }

        public void AddNewBook(Book book)
        {
            if (TotalBook < listOfBook.Length)
            {
                listOfBook[TotalBook] = book;
                TotalBook++;
                Console.WriteLine($"{book.BookName} has been added to the library.");
            }
            else
            {
                Console.WriteLine("Library is at maximum capacity.");
            }
        }

        public void DeleteBook(Book book)
        {
            for (int i = 0; i < TotalBook; i++)
            {
                if (listOfBook[i] == book)
                {
                    for (int j = i; j < TotalBook - 1; j++)
                    {
                        listOfBook[j] = listOfBook[j + 1];
                    }
                    TotalBook--;
                    Console.WriteLine($"{book.BookName} has been deleted from the library.");
                    break;
                }
            }
        }

        public void AddNewBookCopy(Book book, int copy)
        {
            foreach (Book b in listOfBook)
            {
                if (b == book)
                {
                    b.AddBookCopy(copy);
                    break;
                }
            }
        }
    }
}
