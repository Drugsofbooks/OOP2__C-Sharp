﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryManagement
{
    /*class Program
    {
        static void Main(string[] args)
        {

            Book b1 = new Book("Shesher Kobita", "Rabindranath Tagor", "ISBN12345", "Poem", 5);

            Book b2 = new Book("Monushotto", "Kazi Nazrul Islam", "ISBN987650", "Story", 9);

            b1.ShowInfo();
            b2.ShowInfo();

            b2.AddBookCopy(3);

            Book.ShowTotalBookInfo();

            Console.ReadLine();
        }
    }*/

    class Program
    {
        static void Main()
        {
            // Create a library
            Library myLibrary = new Library("Abid's Library", "84 East Basabo");

            // Create and add books to the library
            Book book1 = new Book("English For today", "Chowdhury", "001", "English", 2);
            Book book2 = new Book("Chemistry", "Hajari Nag", "002", "Chemilcal", 4);
            myLibrary.AddNewBook(book1);
            myLibrary.AddNewBook(book2);

            // Show library information
            myLibrary.ShowLibInfo();

            // Show book information
            book1.ShowInfo();


            book2.ShowInfo();

            // Add more copies of a book
            myLibrary.AddNewBookCopy(book1, 3);

            // Show updated book information
            book1.ShowInfo();

            // Delete a book
            myLibrary.DeleteBook(book2);

            // Show updated library information
            myLibrary.ShowLibInfo();

            // Show total book count
            Book.ShowTotalBookInfo();

            Console.ReadLine();
        }
    }
}
