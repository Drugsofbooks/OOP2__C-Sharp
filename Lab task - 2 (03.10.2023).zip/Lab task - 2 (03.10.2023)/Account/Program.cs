﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Account
{
    class Program
    {
        static void Main()
        {
            Account a1 = new Account("Abid Nazir", "2245312", 1000);
            a1.ShowInfo();
            a1.Deposit(500);
            a1.Withdraw(200);

            Console.ReadLine();
        }
    }
}
