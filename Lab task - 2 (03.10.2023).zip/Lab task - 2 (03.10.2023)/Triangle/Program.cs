﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Triangle
{
    class Program
    {
        static void Main()
        {
            Triangle t1 = new Triangle(3, 3, 3);
            t1.ShowInfo();
            t1.TestTriangle();

            Triangle t2 = new Triangle(4, 3, 4);
            t2.ShowInfo();
            t2.TestTriangle();

            Triangle t3 = new Triangle(3, 4, 5);
            t3.ShowInfo();
            t3.TestTriangle();

            Console.ReadLine();

        }
    }
}
