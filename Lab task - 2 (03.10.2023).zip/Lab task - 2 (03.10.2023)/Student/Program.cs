﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student
{
    class Program
    {
        static void Main()
        {
            Student s1 = new Student();
            s1.setName("Afzalul Abid Nazir");
            s1.setId("21-45395-3");
            s1.setDept("CSE");
            s1.setCgpa(3.97f);
            s1.ShowInfo();
            Console.ReadLine();
        }
    }
}
