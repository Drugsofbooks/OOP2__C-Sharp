﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Account
{
    class Program
    {
        static void Main()
        {
            Account a1 = new Account("Abid Nazir", "2245312", 5000);
            a1.ShowInfo();
            a1.Deposit(500);

            Account a2 = new Account("Virat Kholi", "3378213", 3000);
            a2.ShowInfo();
            a2.Withdraw(800);

            a1.Transfer(200, a2);

            Console.WriteLine("-----------------------------------");
            Console.WriteLine("New Account Balance of "+a1.getName()+" is : " + a1.getBalance());
            Console.WriteLine("New Account Balance of "+a2.getName()+" is : " + a2.getBalance());
            Console.ReadLine();
        }
    }
}
