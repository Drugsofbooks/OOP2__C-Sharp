﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contact
{
    class Contact
    {
        private String personName;
        private String personId;
        private int age;
        private String mobileNumber;
        private Char gender;

        public void setName(String personName) { this.personName = personName; }
        public String getName() { return personName; }

        public void setId(String personId) { this.personId = personId; }
        public String getId() { return personId; }

        public void setAge(int age) { this.age = age; }
        public int getAge() { return age; }

        public void setNumber(String mobileNumber) { this.mobileNumber = mobileNumber; }
        public String getNumber() { return mobileNumber; }
        public void setGender(Char gender) { this.gender = gender; }
        public Char getGender() { return gender; }

        public Contact() {}

        public Contact(String personName, String personId, int age, String mobileNumber, Char gender)
        {
            this.personName = personName;
            this.personId = personId;
            this.age = age;
            this.mobileNumber = mobileNumber;
            this.gender = gender;
        }

        public void ShowInfo()
        {
            Console.WriteLine("Name is          : "+personName);
            Console.WriteLine("ID is            : "+personId);
            Console.WriteLine("Age is           : "+age);
            Console.WriteLine("Mobile Number is : "+mobileNumber);
            Console.WriteLine("Gender is        : "+gender);
        }

        public static String Detect(String mobileNumber)
        {
            if (string.IsNullOrWhiteSpace(mobileNumber) || mobileNumber.Length < 3)
            {
                return "Invalid Mobile Number";
            }

            if (mobileNumber=="017")
            Console.WriteLine("Mobile Operator: GP");
            else
                Console.WriteLine("Mobile Operator: BL");
        }
    }
}
