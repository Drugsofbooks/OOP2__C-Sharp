﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contact
{
    class Program
    {
        static void Main (string [] args)
        {
            Contact cc1 = new Contact("John Doe", "12345", 30, "017XXXXXXXX", 'M');
            cc1.ShowInfo();
            cc1.DetectMobileOperator();
            Console.ReadLine();
        }
    }
}
