﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Book
{
    class Program
    {
        static void Main(string[] args)
        {

            Book b1 = new Book("Shesher Kobita", "Rabindranath Tagor", "ISBN12345", "Poem", 5);

            Book b2 = new Book("Monushotto", "Kazi Nazrul Islam", "ISBN987650", "Story", 9);

            b1.ShowInfo();
            b2.ShowInfo();

            b2.AddBookCopy(3);

            Book.ShowTotalBookInfo();

            Console.ReadLine();
        }
    }
}
