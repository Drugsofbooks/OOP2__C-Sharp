﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SportsManagement
{
    class CricketBat : SportsItem
    {
        public double Height { get; set; }
        public double Width { get; set; }

        public CricketBat()
        {
            Height = 0.0;
            Width = 0.0;
        }

        public CricketBat(string brand, double price, int quantity, double height, double width)
            : base(brand, price, quantity)
        {
            Height = height;
            Width = width;
        }

        public void ShowItemInfo()
        {
            base.ShowItemInfo();
            Console.WriteLine("Item Size       : " +Height+" & "+Width);
        }
    }
}
