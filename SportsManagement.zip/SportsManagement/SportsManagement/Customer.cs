﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SportsManagement
{
    class Customer
    {
        public string CustomerName { get; set; }
        public int NoOfItem { get; set; }
        public double TotalPay { get; set; }

        public Customer()
        {
            CustomerName = "";
            NoOfItem = 0;
            TotalPay = 0.0;
        }

        public Customer(string customerName, int noOfItem, double totalPay)
        {
            CustomerName = customerName;
            NoOfItem = noOfItem;
            TotalPay = totalPay;
        }

        public string GetCustomerName()
        {
            return CustomerName;
        }

        public int GetNoOfItem()
        {
            return NoOfItem;
        }

        public double GetTotalPay()
        {
            return TotalPay;
        }

        public void ShowCustomerInfo()
        {
            Console.WriteLine("Customer Name   : " + CustomerName);
            Console.WriteLine("Total Items     : " + NoOfItem);
            Console.WriteLine("Total Payment   : " + TotalPay);
        }
    }
}
