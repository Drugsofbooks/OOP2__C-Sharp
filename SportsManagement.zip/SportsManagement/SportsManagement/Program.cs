﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SportsManagement
{
    class Program
    {
        static void Main(string[] args)
        {
            Customer customer1 = new Customer("Virat Kohli", 2, 10000.0);
            customer1.ShowCustomerInfo();

            CricketBat cricketBat = new CricketBat("Kookaburra", 5000.0, 10, 5.5, 6.6);
            cricketBat.ShowItemInfo();

            Console.WriteLine();

            Customer customer2 = new Customer("Cristiano Ronaldo", 3, 20000.0);
            customer2.ShowCustomerInfo();

            Football football = new Football("Adidas", 6000.0, 20, 4.5);
            football.ShowItemInfo();

            Console.ReadLine();
        }
    }
}
