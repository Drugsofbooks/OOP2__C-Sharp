﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SportsManagement
{
    class SportsItem
    {
        public string Brand { get; set; }
        public double Price { get; set; }
        public int Quantity { get; set; }

        public SportsItem()
        {
            Brand = "";
            Price = 0.0;
            Quantity = 0;
        }

        public SportsItem(string brand, double price, int quantity)
        {
            Brand = brand;
            Price = price;
            Quantity = quantity;
        }

        public void SetPrice(double price)
        {
            Price = price;
        }

        public double GetPrice()
        {
            return Price;
        }

        public int GetQuantity()
        {
            return Quantity;
        }

        public void ShowItemInfo()
        {
            Console.WriteLine("Item Brand      : " + Brand);
            Console.WriteLine("Item Price      : " + Price);
            Console.WriteLine("Item Quantity   : " + Quantity);
        }
    }
}
