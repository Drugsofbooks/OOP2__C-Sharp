﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SportsManagement
{
    class Football : SportsItem
    {
        public double Radius { get; set; }

        public Football()
        {
            Radius = 0.0;
        }

        public Football(string brand, double price, int quantity, double radius)
            : base(brand, price, quantity)
        {
            Radius = radius;
        }

        public void ShowItemInfo()
        {
            base.ShowItemInfo();
            Console.WriteLine("Item Size       : " + Radius);
        }
    }
}
